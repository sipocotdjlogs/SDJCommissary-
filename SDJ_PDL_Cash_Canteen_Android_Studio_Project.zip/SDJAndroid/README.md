# SDJ PDL Cash & Canteen – Android Studio project

This is a native Android wrapper project for the offline SDJ prototype. It includes native CameraX + ML Kit barcode scanning and OCR label recognition. The existing HTML app remains the local UI and uses browser localStorage for its prototype data.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder (`SDJAndroid`) as an Android Studio project.
3. Allow Gradle sync and dependency downloads.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations before operational use
- This is a prototype, not an approved BJMP financial/accounting system.
- Prototype data uses WebView localStorage. It is not encrypted and does not yet have an authenticated role model or tamper-evident audit storage.
- Barcode scanning identifies a barcode value; it does not magically know every product name. Register products in the local catalog and map their barcode to a verified item record.
- ML Kit text recognition is bundled for Latin text; OCR output must be checked by the operator before saving.
- Do not enter real PDL personal or financial information until the agency approves security, privacy, backup, access, retention, and audit controls.

Package: `ph.gov.bjmp.sdj`  
Version: `0.1.0` (prototype)
