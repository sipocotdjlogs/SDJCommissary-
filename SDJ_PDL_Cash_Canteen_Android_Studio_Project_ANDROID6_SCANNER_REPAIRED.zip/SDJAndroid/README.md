# SDJ PDL Cash & Canteen – Android Studio project

This is a native Android wrapper project for the offline SDJ prototype. It includes native CameraX + bundled ML Kit barcode scanning and OCR label recognition. Minimum supported Android version is Android 6.0 (API 23). The existing HTML app remains the local UI and uses browser localStorage for its prototype data.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder (`SDJAndroid`) as an Android Studio project.
3. Allow Gradle sync and dependency downloads.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Scanner compatibility and behavior
- Minimum Android version is API 23 (Android 6.0), matching ML Kit barcode-scanning requirements.
- CameraX supports Android API 21+, and the ML Kit barcode dependency requires API 23+.
- The scanner uses a lifecycle-bound CameraX preview and analyzer, reuses ML Kit clients, closes each camera frame after processing, and releases camera/scanner resources when the activity closes.
- The app requests camera permission at runtime and displays an error/retry message if permission is denied, no usable camera is present, or camera startup fails.
- Barcode recognition uses the bundled ML Kit model so the barcode model is available without a first-use model download. OCR uses the bundled Latin text recognizer.
- Compatibility still depends on the device having a working camera and a supported Android implementation; test on representative phones before deployment.

## Important limitations before operational use
- This is a prototype, not an approved BJMP financial/accounting system.
- Prototype data uses WebView localStorage. It is not encrypted and does not yet have an authenticated role model or tamper-evident audit storage.
- Barcode scanning identifies a barcode value; it does not magically know every product name. Register products in the local catalog and map their barcode to a verified item record.
- ML Kit text recognition is bundled for Latin text; OCR output must be checked by the operator before saving.
- Do not enter real PDL personal or financial information until the agency approves security, privacy, backup, access, retention, and audit controls.

Package: `ph.gov.bjmp.sdj`  
Version: `0.1.0` (prototype)
