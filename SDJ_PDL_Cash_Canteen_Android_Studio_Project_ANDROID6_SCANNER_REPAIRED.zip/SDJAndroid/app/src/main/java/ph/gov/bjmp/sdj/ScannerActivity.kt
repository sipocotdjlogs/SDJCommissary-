package ph.gov.bjmp.sdj

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** CameraX + bundled ML Kit scanner. All camera work is lifecycle-bound and failures are shown in UI. */
class ScannerActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusView: TextView
    private lateinit var retryButton: Button
    private lateinit var cameraExecutor: ExecutorService

    private val finished = AtomicBoolean(false)
    private val analyzing = AtomicBoolean(false)
    private var mode: String = MODE_BARCODE
    private var cameraProvider: ProcessCameraProvider? = null
    private var barcodeScanner: BarcodeScanner? = null
    private var textRecognizer: TextRecognizer? = null

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else showError("Camera permission was denied. Allow Camera permission in App settings, then tap Retry.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        mode = if (intent.getStringExtra(EXTRA_MODE) == MODE_OCR) MODE_OCR else MODE_BARCODE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        statusView = TextView(this).apply {
            textSize = 16f
            text = if (mode == MODE_BARCODE) "Point the camera at a barcode" else "Frame the product label"
            setPadding(0, 0, 0, dp(12))
        }
        previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        retryButton = Button(this).apply {
            text = "Retry camera"
            visibility = android.view.View.GONE
            setOnClickListener { requestCameraOrStart() }
        }
        val cancelButton = Button(this).apply {
            text = "Cancel"
            setOnClickListener { setResult(Activity.RESULT_CANCELED); finish() }
        }
        root.addView(statusView)
        root.addView(previewView)
        root.addView(retryButton)
        root.addView(cancelButton)
        setContentView(root)

        try {
            val barcodeOptions = BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                    Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E,
                    Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
                    Barcode.FORMAT_QR_CODE
                ).build()
            barcodeScanner = BarcodeScanning.getClient(barcodeOptions)
            textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        } catch (e: Exception) {
            showError("Scanner could not initialize: ${e.localizedMessage ?: "Unknown error"}")
            return
        }
        requestCameraOrStart()
    }

    private fun requestCameraOrStart() {
        retryButton.visibility = android.view.View.GONE
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        if (isFinishing || isDestroyed) return
        statusView.text = "Starting camera…"
        try {
            val future = ProcessCameraProvider.getInstance(this)
            future.addListener({
                if (isFinishing || isDestroyed) return@addListener
                try {
                    val provider = future.get()
                    cameraProvider = provider
                    val selector = when {
                        CameraSelector.DEFAULT_BACK_CAMERA.filter(provider.availableCameraInfos).isNotEmpty() -> CameraSelector.DEFAULT_BACK_CAMERA
                        CameraSelector.DEFAULT_FRONT_CAMERA.filter(provider.availableCameraInfos).isNotEmpty() -> CameraSelector.DEFAULT_FRONT_CAMERA
                        else -> throw IllegalStateException("No usable camera was found on this device.")
                    }
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        if (finished.get() || !analyzing.compareAndSet(false, true)) {
                            imageProxy.close()
                            return@setAnalyzer
                        }
                        val mediaImage = imageProxy.image
                        if (mediaImage == null) {
                            analyzing.set(false)
                            imageProxy.close()
                            return@setAnalyzer
                        }
                        val input = try {
                            InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                        } catch (e: Exception) {
                            analyzing.set(false)
                            imageProxy.close()
                            return@setAnalyzer
                        }
                        if (mode == MODE_OCR) {
                            val client = textRecognizer
                            if (client == null) {
                                analyzing.set(false)
                                imageProxy.close()
                            } else {
                                client.process(input)
                                    .addOnSuccessListener { result ->
                                        val recognized = result.text.replace('\n', ' ').trim()
                                        if (recognized.length >= 3) finishWith(recognized.take(100))
                                    }
                                    .addOnFailureListener { error -> showScanningError(error) }
                                    .addOnCompleteListener { analyzing.set(false); imageProxy.close() }
                            }
                        } else {
                            val client = barcodeScanner
                            if (client == null) {
                                analyzing.set(false)
                                imageProxy.close()
                            } else {
                                client.process(input)
                                    .addOnSuccessListener { codes ->
                                        val value = codes.firstNotNullOfOrNull { it.rawValue?.takeIf(String::isNotBlank) }
                                        if (value != null) finishWith(value)
                                    }
                                    .addOnFailureListener { error -> showScanningError(error) }
                                    .addOnCompleteListener { analyzing.set(false); imageProxy.close() }
                            }
                        }
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(this, selector, preview, analysis)
                    statusView.text = if (mode == MODE_OCR) "Frame the product label; hold steady" else "Point camera at the barcode"
                } catch (e: Exception) {
                    showError("Unable to start camera: ${e.localizedMessage ?: e.javaClass.simpleName}")
                }
            }, ContextCompat.getMainExecutor(this))
        } catch (e: Exception) {
            showError("Camera is unavailable: ${e.localizedMessage ?: e.javaClass.simpleName}")
        }
    }

    private fun showScanningError(error: Exception) {
        runOnUiThread {
            if (!finished.get() && !isFinishing && !isDestroyed) {
                statusView.text = "Scanning is still active. ${error.localizedMessage ?: "Try adjusting the barcode or label."}"
            }
        }
    }

    private fun showError(message: String) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                statusView.text = message
                retryButton.visibility = android.view.View.VISIBLE
            }
        }
    }

    private fun finishWith(value: String) {
        if (!finished.compareAndSet(false, true)) return
        runOnUiThread {
            setResult(Activity.RESULT_OK, Intent().putExtra(EXTRA_MODE, mode).putExtra(EXTRA_VALUE, value))
            finish()
        }
    }

    override fun onStop() {
        cameraProvider?.unbindAll()
        super.onStop()
    }

    override fun onDestroy() {
        finished.set(true)
        cameraProvider?.unbindAll()
        barcodeScanner?.close()
        textRecognizer?.close()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_VALUE = "value"
        const val MODE_BARCODE = "barcode"
        const val MODE_OCR = "ocr"
    }
}
