package ph.gov.bjmp.sdj

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** CameraX + ML Kit scanner. Supports Android 6.0 (API 23) and later. */
class ScannerActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private var controller: LifecycleCameraController? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val processing = AtomicBoolean(false)
    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startCamera()
        } else if (::status.isInitialized) {
            status.text = "Camera permission is required. Enable it in App Settings, then reopen the scanner."
        }
    }
    private val finished = AtomicBoolean(false)
    private val barcodeScanner by lazy { BarcodeScanning.getClient() }
    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }
    private var mode: String = "barcode"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "barcode"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 24, 12, 12)
        }
        status = TextView(this).apply {
            text = if (mode == "barcode") "Point camera at barcode" else "Frame the product label; text will be recognized"
            textSize = 16f
        }
        preview = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val close = Button(this).apply {
            text = "Cancel"
            setOnClickListener {
                setResult(RESULT_CANCELED)
                finish()
            }
        }
        root.addView(status)
        root.addView(preview)
        root.addView(close)
        setContentView(root)
        checkCameraPermissionAndStart()
    }

    private fun checkCameraPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        try {
            val cameraController = LifecycleCameraController(this)
            cameraController.cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            cameraController.imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
            cameraController.setImageAnalysisAnalyzer(cameraExecutor) { imageProxy -> analyze(imageProxy) }
            controller = cameraController
            preview.controller = cameraController
            cameraController.bindToLifecycle(this)
        } catch (error: Exception) {
            status.text = "Unable to start camera: ${error.localizedMessage ?: "Camera unavailable"}"
        }
    }

    private fun analyze(imageProxy: ImageProxy) {
        if (finished.get() || !processing.compareAndSet(false, true)) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            processing.set(false)
            imageProxy.close()
            return
        }
        try {
            val input = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            if (mode == "barcode") {
                barcodeScanner.process(input)
                    .addOnSuccessListener { barcodes ->
                        barcodes.firstOrNull()?.rawValue?.let { value -> finishWith(value) }
                    }
                    .addOnFailureListener { error -> showScanError(error.localizedMessage) }
                    .addOnCompleteListener {
                        processing.set(false)
                        imageProxy.close()
                    }
            } else {
                textRecognizer.process(input)
                    .addOnSuccessListener { result ->
                        val candidate = result.textBlocks.joinToString(" ") { it.text }.trim()
                        if (candidate.length >= 3) finishWith(candidate.take(100))
                    }
                    .addOnFailureListener { error -> showScanError(error.localizedMessage) }
                    .addOnCompleteListener {
                        processing.set(false)
                        imageProxy.close()
                    }
            }
        } catch (error: Exception) {
            processing.set(false)
            imageProxy.close()
            showScanError(error.localizedMessage)
        }
    }

    private fun showScanError(message: String?) {
        runOnUiThread {
            if (!finished.get()) status.text = "Scan error: ${message ?: "Please try again"}"
        }
    }

    private fun finishWith(value: String) {
        if (value.isBlank() || !finished.compareAndSet(false, true)) return
        runOnUiThread {
            setResult(RESULT_OK, Intent().putExtra("mode", mode).putExtra("value", value))
            finish()
        }
    }

    override fun onDestroy() {
        try {
            controller?.clearImageAnalysisAnalyzer()
            controller?.unbind()
            controller = null
        } catch (_: Exception) {
        }
        cameraExecutor.shutdown()
        try { barcodeScanner.close() } catch (_: Exception) { }
        try { textRecognizer.close() } catch (_: Exception) { }
        super.onDestroy()
    }

    companion object {
    }
}
