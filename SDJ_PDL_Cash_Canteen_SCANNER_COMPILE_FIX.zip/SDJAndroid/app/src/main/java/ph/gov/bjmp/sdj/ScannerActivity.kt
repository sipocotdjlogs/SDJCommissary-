package ph.gov.bjmp.sdj

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ScannerActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val processing = AtomicBoolean(false)
    private val finished = AtomicBoolean(false)
    private val barcodeScanner by lazy { BarcodeScanning.getClient() }
    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }
    private var mode: String = "barcode"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "barcode"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 24, 12, 12)
        }
        status = TextView(this).apply {
            text = if (mode == "barcode") "Point camera at barcode"
            else "Frame the product label; text will be recognized"
            textSize = 16f
        }
        preview = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val close = Button(this).apply {
            text = "Cancel"
            setOnClickListener {
                setResult(RESULT_CANCELED)
                finish()
            }
        }
        root.addView(status)
        root.addView(preview)
        root.addView(close)
        setContentView(root)

        checkCameraPermissionAndStart()
    }

    private fun checkCameraPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
        }
    }

    @Deprecated("Deprecated in Android API; retained for API 23 compatibility")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                status.text = "Camera permission is required. Enable it in App Settings."
            }
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val cameraProvider = providerFuture.get()
                val previewUseCase = Preview.Builder().build().also {
                    it.setSurfaceProvider(preview.surfaceProvider)
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    if (finished.get() || !processing.compareAndSet(false, true)) {
                        imageProxy.close()
                        return@setAnalyzer
                    }

                    val mediaImage = imageProxy.image
                    if (mediaImage == null) {
                        processing.set(false)
                        imageProxy.close()
                        return@setAnalyzer
                    }

                    val input = InputImage.fromMediaImage(
                        mediaImage,
                        imageProxy.imageInfo.rotationDegrees
                    )

                    val task = if (mode == "barcode") {
                        barcodeScanner.process(input).addOnSuccessListener { barcodes ->
                            barcodes.firstOrNull()?.rawValue?.let { value -> finishWith(value) }
                        }
                    } else {
                        textRecognizer.process(input).addOnSuccessListener { result ->
                            val candidate = result.textBlocks
                                .joinToString(" ") { block -> block.text }
                                .trim()
                            if (candidate.length >= 3) finishWith(candidate.take(100))
                        }
                    }

                    task.addOnFailureListener { error ->
                        runOnUiThread {
                            if (!finished.get()) {
                                status.text = "Scan error: ${error.localizedMessage ?: "Try again"}"
                            }
                        }
                    }.addOnCompleteListener {
                        processing.set(false)
                        imageProxy.close()
                    }
                }

                cameraProvider.unbindAll()
                val owner: LifecycleOwner = this@ScannerActivity
                cameraProvider.bindToLifecycle(
                    owner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    previewUseCase,
                    analysis
                )
            } catch (error: Exception) {
                status.text = "Unable to start camera: ${error.localizedMessage ?: "Camera unavailable"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun finishWith(value: String) {
        if (!finished.compareAndSet(false, true)) return
        runOnUiThread {
            val result = Intent().putExtra("mode", mode).putExtra("value", value)
            setResult(RESULT_OK, result)
            finish()
        }
    }

    override fun onDestroy() {
        try {
            // Stop camera use cases before releasing analyzer resources.
            ProcessCameraProvider.getInstance(this).get().unbindAll()
        } catch (_: Exception) {
        }
        cameraExecutor.shutdown()
        try { barcodeScanner.close() } catch (_: Exception) {}
        try { textRecognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CAMERA_PERMISSION_REQUEST = 4102
    }
}
