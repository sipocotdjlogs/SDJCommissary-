# SDJ Cash & Canteen Android Project

## Project contents
- Android application (minimum Android 6.0 / API 23)
- Local HTML interface bundled in `app/src/main/assets/index.html`
- Sipocot District Jail and BJMP logos only
- CameraX + ML Kit barcode and text recognition scanner
- PDL wallet, deposits, canteen inventory, purchases, reconciliation, reports, JSON backup and audit trail

## Build
Open this `SDJAndroid` folder as an Android Gradle project, or use the repository GitHub Actions workflow. The workflow ZIP filename must match the `ZIP_FILE` value in `.github/workflows/build.yml`.

## Important operational and security limitations
This build stores records in WebView local storage on one device. The local data is not encrypted, not synchronized, and is not a server-backed ledger. The administrator password is a local-device gate, not enterprise authentication or tamper-proof security. JSON/CSV exports must be stored in an approved secure location. Do not treat the app as an official financial system until it has undergone agency IT/security review, access-control approval, backup/restore testing, accounting validation, and operational acceptance testing.

The audit export is Excel-compatible CSV, not a native multi-sheet `.xlsx` workbook.
