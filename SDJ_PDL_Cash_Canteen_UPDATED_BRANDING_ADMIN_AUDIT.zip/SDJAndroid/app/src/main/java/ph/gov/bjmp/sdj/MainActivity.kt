package ph.gov.bjmp.sdj

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingExportBytes: ByteArray? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true // Required for bundled android_asset files.
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
        }
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Keep navigation inside the bundled local application only.
                return url == null || !url.startsWith("file:///android_asset/")
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidSDJ")
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html")
        else web.restoreState(savedInstanceState)
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(fileName: String, mimeType: String, base64Content: String) {
            runOnUiThread {
                try {
                    pendingExportBytes = Base64.decode(base64Content, Base64.DEFAULT)
                    val safeName = fileName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "SDJ-audit.csv" }
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mimeType.ifBlank { "text/csv" }
                        putExtra(Intent.EXTRA_TITLE, safeName)
                    }
                    startActivityForResult(intent, SAVE_FILE_REQUEST)
                } catch (e: Exception) {
                    pendingExportBytes = null
                    Toast.makeText(this@MainActivity, "Unable to prepare export: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun startScanner(mode: String) {
            runOnUiThread {
                val safeMode = if (mode == "ocr") "ocr" else "barcode"
                startActivityForResult(
                    Intent(this@MainActivity, ScannerActivity::class.java).putExtra("mode", safeMode),
                    SCANNER_REQUEST
                )
            }
        }
    }

    @Deprecated("Deprecated Android API; retained for API 23 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SCANNER_REQUEST && resultCode == RESULT_OK) {
            val mode = data?.getStringExtra("mode") ?: return
            val value = data.getStringExtra("value") ?: return
            val js = "window.onNativeScan(${org.json.JSONObject.quote(mode)},${org.json.JSONObject.quote(value)});"
            web.evaluateJavascript(js, null)
        } else if (requestCode == SAVE_FILE_REQUEST) {
            val bytes = pendingExportBytes
            pendingExportBytes = null
            if (resultCode == RESULT_OK && data?.data != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes) }
                    Toast.makeText(this, "Audit report saved successfully.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not save report: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::web.isInitialized) web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated Android API; retained for API 23 compatibility")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("AndroidSDJ")
            web.stopLoading()
            web.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val SCANNER_REQUEST = 41
        private const val SAVE_FILE_REQUEST = 42
    }
}
