package ph.gov.bjmp.sdj

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ScannerActivity : Activity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val done = AtomicBoolean(false)
    private var mode = "barcode"
    private val barcodeClient by lazy { BarcodeScanning.getClient() }
    private val textClient by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else { status.text = "Camera permission is required." }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "barcode"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 24, 12, 12) }
        status = TextView(this).apply { text = if (mode == "barcode") "Point camera at barcode" else "Frame the product label; text will be recognized"; textSize = 16f }
        preview = PreviewView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val close = Button(this).apply { text = "Cancel"; setOnClickListener { setResult(Activity.RESULT_CANCELED); finish() } }
        root.addView(status); root.addView(preview); root.addView(close)
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }
    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy ->
                if (done.get()) { proxy.close(); return@setAnalyzer }
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                if (mode == "barcode") {
                    barcodeClient.process(image)
                        .addOnSuccessListener { codes -> codes.firstOrNull()?.rawValue?.let { finishWith(it) } }
                        .addOnCompleteListener { proxy.close() }
                } else {
                    textClient.process(image)
                        .addOnSuccessListener { result ->
                            val candidate = result.textBlocks.joinToString(" ") { it.text }.trim()
                            if (candidate.length >= 3) finishWith(candidate.take(100))
                        }.addOnCompleteListener { proxy.close() }
                }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
            } catch (e: Exception) { status.text = "Unable to start camera: ${e.localizedMessage}" }
        }, ContextCompat.getMainExecutor(this))
    }
    private fun finishWith(value: String) {
        if (!done.compareAndSet(false, true)) return
        runOnUiThread {
            setResult(Activity.RESULT_OK, Intent().putExtra("mode", mode).putExtra("value", value))
            finish()
        }
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdown(); barcodeClient.close(); textClient.close() }
}
